This is the TYPO3 Introduction Package
======================================


This carefully crafted extension gives
you a small insight in the powerful toolbox
of the TYPO3 CMS framework.

It comes with a full-fletched website, delivering
a theme based on Twitter bootstrap with simple
options to modify the base theme.

Installation:
-------------

Donwload and install `introduction` through extension manager in the back-end of you TYPO3 installation.

Or add `introduction` via composer `composer require typo3/cms-introduction` to your exising 
project and go the the extension manager in the back-end to install it.

Credits
-------

Kudos go to all contributors:

* Benjamin Kott for the large part of developing this extension,
* Sven Wolfermann for the first version of the package,
* Ben van't Ende and Mathias Schreiber for kicking butts.
