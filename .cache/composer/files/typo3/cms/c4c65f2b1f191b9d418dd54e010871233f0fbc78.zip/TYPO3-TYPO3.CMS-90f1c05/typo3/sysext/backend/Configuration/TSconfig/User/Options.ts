options.disableDelete.sys_file_metadata = 1
