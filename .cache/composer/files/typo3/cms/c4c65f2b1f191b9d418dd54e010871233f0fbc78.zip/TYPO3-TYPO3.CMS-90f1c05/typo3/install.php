<?php

require __DIR__ . '/sysext/install/Resources/Private/Php/install.php';
