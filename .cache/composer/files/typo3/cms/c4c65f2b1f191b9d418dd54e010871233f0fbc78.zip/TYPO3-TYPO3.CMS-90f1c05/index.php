<?php

require __DIR__ . '/typo3/sysext/frontend/Resources/Private/Php/frontend.php';
