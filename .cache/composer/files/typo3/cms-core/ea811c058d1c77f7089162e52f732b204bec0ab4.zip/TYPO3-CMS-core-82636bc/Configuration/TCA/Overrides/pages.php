<?php
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::makeCategorizable(
    'core',
    'pages',
    'categories',
    [
        'position' => 'replace:categories'
    ]
);
